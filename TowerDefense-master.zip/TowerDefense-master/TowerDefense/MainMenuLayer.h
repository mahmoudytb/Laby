//
//  MainMenuLayer.h
//  TowerDefense
//
//  Created by Benjamin Chen on 4/16/13.
//
//

#import "cocos2d.h"

@interface MainMenuLayer : CCLayer
{
    CCMenu *mainMenu;
}

-(void)displayMainMenu;

@end
