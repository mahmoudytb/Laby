//
//  BlueTower.h
//  TowerDefense
//
//  Created by Benjamin Chen on 4/25/13.
//
//

#import "TowerObject.h"
#import "GameConstants.h"
#import "cocos2d.h"

@interface BlueTower : TowerObject
{
    
}

@end
