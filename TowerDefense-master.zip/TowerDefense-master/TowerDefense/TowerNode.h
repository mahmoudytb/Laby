//
//  TowerNode.h
//  TowerDefense
//
//  Created by Benjamin Chen on 6/18/13.
//
//

#import "TowerObject.h"
#import "GameConstants.h"
#import "cocos2d.h"

@interface TowerNode : TowerObject
{
    
}

@end
