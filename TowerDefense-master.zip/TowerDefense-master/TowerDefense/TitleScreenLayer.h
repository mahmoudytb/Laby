//
//  TitleScreenLayer.h
//  TowerDefense
//
//  Created by Benjamin Chen on 5/10/13.
//
//

#import "cocos2d.h"

@interface TitleScreenLayer : CCLayer
{
    
}

@end
